# Import all cloud adapters for easy access
from .aws_adapter import AWSAdapter
from .azure_adapter import AzureAdapter
from .gcp_adapter import GCPAdapter

# Instantiate adapters for direct use
aws_adapter = AWSAdapter()
azure_adapter = AzureAdapter()
gcp_adapter = GCPAdapter()

__all__ = ['aws_adapter', 'azure_adapter', 'gcp_adapter']
