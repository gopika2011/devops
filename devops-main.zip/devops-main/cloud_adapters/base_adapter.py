from datetime import datetime, timedelta
import uuid
import json
import random
import os

class BaseCloudAdapter:
    """Base class for all cloud platform adapters"""
    
    def __init__(self, platform_name):
        self.platform_name = platform_name
        self.api_key = os.getenv(f"{platform_name.upper()}_API_KEY", "")
        self.api_base_url = os.getenv(f"{platform_name.upper()}_API_URL", "")
    
    def get_deployments(self):
        """
        Get deployments from the cloud platform.
        This method should be implemented by each specific adapter.
        """
        raise NotImplementedError("Each cloud adapter must implement get_deployments()")
    
    def get_deployment_logs(self, deployment_id):
        """
        Get logs for a specific deployment.
        This method should be implemented by each specific adapter.
        """
        raise NotImplementedError("Each cloud adapter must implement get_deployment_logs()")
    
    def format_deployment(self, raw_deployment):
        """
        Format raw deployment data into a standardized format.
        This method should be implemented by each specific adapter.
        """
        raise NotImplementedError("Each cloud adapter must implement format_deployment()")
    
    def handle_api_error(self, error):
        """
        Handle API errors in a standardized way.
        """
        print(f"Error connecting to {self.platform_name} API: {str(error)}")
        return []
    
    def validate_api_response(self, response):
        """
        Validate API responses in a standardized way.
        """
        if response.status_code != 200:
            raise Exception(f"API returned status code {response.status_code}: {response.text}")
