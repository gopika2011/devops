import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any

def create_deployment_timeline(deployments: List[Dict[str, Any]]) -> go.Figure:
    """
    Create a timeline visualization of deployments
    
    Args:
        deployments: List of deployment dictionaries
        
    Returns:
        Plotly figure object with the timeline
    """
    if not deployments:
        # Return empty figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No deployment data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Prepare data for timeline
    timeline_data = []
    
    for dep in deployments:
        start_time = pd.to_datetime(dep.get('start_time', datetime.now()))
        end_time = pd.to_datetime(dep.get('end_time', datetime.now() if dep.get('status') != 'Running' else None))
        
        # For running deployments, use current time as end
        if dep.get('status') == 'Running' or not end_time:
            end_time = datetime.now()
        
        # Map status to color
        color_map = {
            'Success': '#4CAF50',  # Green
            'Failed': '#F44336',   # Red
            'Running': '#2196F3',  # Blue
            'Pending': '#FFC107'   # Yellow
        }
        
        color = color_map.get(dep.get('status', ''), '#9E9E9E')  # Default to gray
        
        timeline_data.append({
            'Task': dep.get('name', ''),
            'Start': start_time,
            'Finish': end_time,
            'Platform': dep.get('platform', ''),
            'Status': dep.get('status', ''),
            'Color': color,
            'ID': dep.get('id', '')
        })
    
    # Create DataFrame for visualization
    df = pd.DataFrame(timeline_data)
    
    # Sort by start time
    df = df.sort_values('Start')
    
    # Create Gantt chart
    fig = px.timeline(
        df,
        x_start='Start',
        x_end='Finish',
        y='Task',
        color='Status',
        color_discrete_map={
            'Success': '#4CAF50',
            'Failed': '#F44336',
            'Running': '#2196F3',
            'Pending': '#FFC107'
        },
        hover_data=['Platform', 'ID']
    )
    
    # Update layout
    fig.update_layout(
        title='Deployment Timeline',
        xaxis_title='Time',
        yaxis_title='Deployment',
        height=400,
        xaxis=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1h", step="hour", stepmode="backward"),
                    dict(count=6, label="6h", step="hour", stepmode="backward"),
                    dict(count=12, label="12h", step="hour", stepmode="backward"),
                    dict(count=1, label="1d", step="day", stepmode="backward"),
                    dict(count=7, label="1w", step="day", stepmode="backward"),
                    dict(step="all")
                ])
            ),
            type="date"
        )
    )
    
    return fig

def create_success_rate_chart(deployments: List[Dict[str, Any]]) -> go.Figure:
    """
    Create a success rate visualization
    
    Args:
        deployments: List of deployment dictionaries
        
    Returns:
        Plotly figure object with the success rate chart
    """
    if not deployments:
        # Return empty figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No deployment data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Filter only completed deployments
    completed = [d for d in deployments if d.get('status') in ['Success', 'Failed']]
    
    if not completed:
        # Return empty figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No completed deployments available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Count successful and failed deployments
    success_count = sum(1 for d in completed if d.get('status') == 'Success')
    failed_count = sum(1 for d in completed if d.get('status') == 'Failed')
    
    # Calculate success rate
    total = success_count + failed_count
    success_rate = (success_count / total) * 100 if total > 0 else 0
    
    # Create gauge chart
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=success_rate,
        title={'text': "Deployment Success Rate"},
        gauge={
            'axis': {'range': [0, 100]},
            'bar': {'color': "#4CAF50"},
            'steps': [
                {'range': [0, 50], 'color': "#F44336"},
                {'range': [50, 80], 'color': "#FFC107"},
                {'range': [80, 100], 'color': "#4CAF50"}
            ],
            'threshold': {
                'line': {'color': "black", 'width': 4},
                'thickness': 0.75,
                'value': success_rate
            }
        }
    ))
    
    # Update layout
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig

def create_deployment_duration_chart(deployments: List[Dict[str, Any]]) -> go.Figure:
    """
    Create a chart showing deployment durations
    
    Args:
        deployments: List of deployment dictionaries
        
    Returns:
        Plotly figure object with the duration chart
    """
    if not deployments:
        # Return empty figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No deployment data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Filter only completed deployments
    completed = [d for d in deployments if d.get('status') in ['Success', 'Failed'] 
                 and d.get('start_time') and d.get('end_time')]
    
    if not completed:
        # Return empty figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No completed deployments with duration data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False
        )
        return fig
    
    # Calculate durations
    duration_data = []
    
    for dep in completed:
        start_time = pd.to_datetime(dep.get('start_time'))
        end_time = pd.to_datetime(dep.get('end_time'))
        
        # Calculate duration in seconds
        duration = (end_time - start_time).total_seconds()
        
        duration_data.append({
            'Name': dep.get('name', ''),
            'Duration': duration / 60,  # Convert to minutes
            'Platform': dep.get('platform', ''),
            'Status': dep.get('status', ''),
            'ID': dep.get('id', '')
        })
    
    # Create DataFrame for visualization
    df = pd.DataFrame(duration_data)
    
    # Sort by duration
    df = df.sort_values('Duration', ascending=False)
    
    # Limit to top 10 for readability
    df = df.head(10)
    
    # Create bar chart
    fig = px.bar(
        df,
        x='Name',
        y='Duration',
        color='Status',
        color_discrete_map={
            'Success': '#4CAF50',
            'Failed': '#F44336'
        },
        hover_data=['Platform', 'ID'],
        title='Deployment Duration (minutes)',
        labels={'Duration': 'Duration (minutes)', 'Name': 'Deployment'}
    )
    
    # Update layout
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=100),
        xaxis_tickangle=-45
    )
    
    return fig
