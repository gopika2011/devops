import streamlit as st
from apscheduler.schedulers.background import BackgroundScheduler
import logging
from datetime import datetime

# Create a global scheduler
scheduler = None

def refresh_data():
    """
    Function to refresh data in Streamlit session state.
    This will be called by the scheduler.
    """
    # Clear the deployments to force a refresh
    if "deployments" in st.session_state:
        st.session_state.deployments = []
    
    # Update last refresh time
    st.session_state.last_refresh = datetime.now()
    
    # Log the refresh
    logging.info(f"Data refreshed at {st.session_state.last_refresh}")
    
    # Force UI to rerun (Note: this won't work directly from a background thread)
    # We'll rely on the next user interaction to trigger the refresh

def setup_scheduler(interval_seconds=60):
    """
    Set up a background scheduler to refresh data at regular intervals
    
    Args:
        interval_seconds: Number of seconds between each refresh
    """
    global scheduler
    
    # Stop any existing scheduler
    if scheduler:
        scheduler.shutdown()
    
    # Create a new scheduler
    scheduler = BackgroundScheduler()
    
    # Add job to refresh data
    scheduler.add_job(
        refresh_data,
        'interval',
        seconds=interval_seconds,
        id='refresh_data_job'
    )
    
    # Start the scheduler
    scheduler.start()
    
    # Log scheduler start
    logging.info(f"Data refresh scheduler started with {interval_seconds} second interval")
    
    # Add a hook to stop the scheduler when the script exits
    import atexit
    atexit.register(lambda: scheduler.shutdown())
