import streamlit as st
import pandas as pd
import yaml
import os
import time
from datetime import datetime, timedelta

from cloud_adapters import aws_adapter, azure_adapter, gcp_adapter
from utils.data_processor import aggregate_deployments, filter_deployments
from utils.visualization import (
    create_deployment_timeline, 
    create_success_rate_chart,
    create_deployment_duration_chart
)
from utils.scheduler import setup_scheduler

# Page configuration
st.set_page_config(
    page_title="Cloud DevOps Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load configuration
@st.cache_data
def load_config():
    if os.path.exists("config.yaml"):
        with open("config.yaml", "r") as f:
            return yaml.safe_load(f)
    return {
        "refresh_interval": 60,  # seconds
        "platforms": ["aws", "azure", "gcp"],
        "retention_days": 30
    }

config = load_config()

# Initialize session state for deployments
if "deployments" not in st.session_state:
    st.session_state.deployments = []
    
if "last_refresh" not in st.session_state:
    st.session_state.last_refresh = None

if "show_logs" not in st.session_state:
    st.session_state.show_logs = False
    
if "selected_deployment" not in st.session_state:
    st.session_state.selected_deployment = None

# Header
st.title("Cloud DevOps Dashboard")

# Sidebar for filters and controls
with st.sidebar:
    st.header("Filters")
    
    # Platform filter
    platforms = config.get("platforms", ["aws", "azure", "gcp"])
    selected_platforms = st.multiselect(
        "Cloud Platforms",
        options=platforms,
        default=platforms
    )
    
    # Status filter
    status_options = ["Running", "Success", "Failed", "Pending"]
    selected_statuses = st.multiselect(
        "Deployment Status",
        options=status_options,
        default=status_options
    )
    
    # Date range filter
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input(
            "From",
            datetime.now() - timedelta(days=7)
        )
    with col2:
        end_date = st.date_input(
            "To",
            datetime.now()
        )
    
    # Manual refresh button
    if st.button("Refresh Data"):
        st.session_state.deployments = []  # Clear to force refresh
        st.rerun()

# Function to fetch deployments from all configured platforms
def fetch_all_deployments():
    all_deployments = []
    
    if "aws" in selected_platforms:
        aws_deps = aws_adapter.get_deployments()
        all_deployments.extend(aws_deps)
        
    if "azure" in selected_platforms:
        azure_deps = azure_adapter.get_deployments()
        all_deployments.extend(azure_deps)
        
    if "gcp" in selected_platforms:
        gcp_deps = gcp_adapter.get_deployments()
        all_deployments.extend(gcp_deps)
    
    return all_deployments

# Get deployments (cached for the session)
@st.cache_data(ttl=config.get("refresh_interval", 60))
def get_deployments():
    return fetch_all_deployments()

# Update deployments if needed
if not st.session_state.deployments:
    with st.spinner("Fetching deployment data..."):
        st.session_state.deployments = get_deployments()
        st.session_state.last_refresh = datetime.now()

# Filter deployments based on user selections
filtered_deployments = filter_deployments(
    st.session_state.deployments,
    platforms=selected_platforms,
    statuses=selected_statuses,
    start_date=start_date,
    end_date=end_date
)

# Main dashboard area
st.header("Deployment Overview")

# Display last refresh time
if st.session_state.last_refresh:
    st.caption(f"Last updated: {st.session_state.last_refresh.strftime('%Y-%m-%d %H:%M:%S')}")

# Active deployments count
active_deployments = [d for d in filtered_deployments if d["status"] == "Running"]
succeeded_deployments = [d for d in filtered_deployments if d["status"] == "Success"]
failed_deployments = [d for d in filtered_deployments if d["status"] == "Failed"]
pending_deployments = [d for d in filtered_deployments if d["status"] == "Pending"]

# Key metrics
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Active Deployments", len(active_deployments))
with col2:
    st.metric("Completed", len(succeeded_deployments))
with col3:
    st.metric("Failed", len(failed_deployments))
with col4:
    st.metric("Pending", len(pending_deployments))

# Success rate calculation
if len(succeeded_deployments) + len(failed_deployments) > 0:
    success_rate = len(succeeded_deployments) / (len(succeeded_deployments) + len(failed_deployments)) * 100
else:
    success_rate = 0

# Tabs for different visualizations
tab1, tab2, tab3, tab4 = st.tabs([
    "Active Deployments", 
    "Deployment History", 
    "Metrics", 
    "Logs"
])

# Tab 1: Active Deployments
with tab1:
    if active_deployments:
        st.subheader("Currently Running Deployments")
        
        # Create a dataframe for active deployments
        active_df = pd.DataFrame(active_deployments)
        
        # Format timestamps for display
        if 'start_time' in active_df.columns:
            active_df['start_time'] = pd.to_datetime(active_df['start_time']).dt.strftime("%Y-%m-%d %H:%M:%S")
        
        # Display active deployments with color highlighting
        def highlight_long_running(val):
            """Highlight deployments running longer than expected"""
            if val == "Running":
                return 'background-color: #FFEB3B'  # Yellow for running
            return ''
        
        # Display the dataframe with styling
        st.dataframe(
            active_df[['id', 'name', 'platform', 'environment', 'start_time', 'status']], 
            use_container_width=True
        )
    else:
        st.info("No active deployments at this time.")

# Tab 2: Deployment History
with tab2:
    st.subheader("Deployment History")
    
    # Timeline visualization
    if filtered_deployments:
        timeline_fig = create_deployment_timeline(filtered_deployments)
        st.plotly_chart(timeline_fig, use_container_width=True)
        
        # Deployments table
        st.subheader("Recent Deployments")
        
        # Create dataframe for display
        df = pd.DataFrame(filtered_deployments)
        
        # Format timestamps for display
        if 'start_time' in df.columns:
            df['start_time'] = pd.to_datetime(df['start_time']).dt.strftime("%Y-%m-%d %H:%M:%S")
        if 'end_time' in df.columns:
            df['end_time'] = pd.to_datetime(df['end_time']).dt.strftime("%Y-%m-%d %H:%M:%S")
        
        # Create clickable dataframe
        deployment_selection = st.dataframe(
            df[['id', 'name', 'platform', 'environment', 'start_time', 'end_time', 'status']], 
            use_container_width=True,
            height=300
        )
        
        # Allow selection of deployment for detailed view
        selected_index = st.selectbox(
            "Select deployment for details",
            options=range(len(filtered_deployments)),
            format_func=lambda x: f"{filtered_deployments[x]['name']} ({filtered_deployments[x]['id']})"
        )
        
        if selected_index is not None:
            st.session_state.selected_deployment = filtered_deployments[selected_index]
            
            # Show deployment details
            with st.expander("Deployment Details", expanded=True):
                dep = st.session_state.selected_deployment
                
                # Display all details in columns
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown(f"**ID:** {dep['id']}")
                    st.markdown(f"**Name:** {dep['name']}")
                    st.markdown(f"**Platform:** {dep['platform']}")
                    st.markdown(f"**Environment:** {dep['environment']}")
                
                with col2:
                    st.markdown(f"**Status:** {dep['status']}")
                    st.markdown(f"**Start Time:** {dep.get('start_time', 'N/A')}")
                    st.markdown(f"**End Time:** {dep.get('end_time', 'N/A')}")
                    
                    # Calculate duration if available
                    if 'start_time' in dep and 'end_time' in dep and dep['status'] != 'Running':
                        start = pd.to_datetime(dep['start_time'])
                        end = pd.to_datetime(dep['end_time'])
                        duration = end - start
                        st.markdown(f"**Duration:** {str(duration)}")
                
                # Display logs if available
                if 'logs' in dep and dep['logs']:
                    with st.expander("Deployment Logs", expanded=False):
                        st.code(dep['logs'])
    else:
        st.info("No deployment history available for the selected filters.")

# Tab 3: Metrics
with tab3:
    st.subheader("Deployment Metrics")
    
    metrics_col1, metrics_col2 = st.columns(2)
    
    with metrics_col1:
        # Success rate chart
        success_fig = create_success_rate_chart(filtered_deployments)
        st.plotly_chart(success_fig, use_container_width=True)
    
    with metrics_col2:
        # Deployment duration chart
        duration_fig = create_deployment_duration_chart(filtered_deployments)
        st.plotly_chart(duration_fig, use_container_width=True)
    
    # Deployment counts by platform
    platform_counts = {}
    for dep in filtered_deployments:
        platform = dep["platform"]
        platform_counts[platform] = platform_counts.get(platform, 0) + 1
    
    st.subheader("Deployments by Platform")
    platform_df = pd.DataFrame({
        "Platform": list(platform_counts.keys()),
        "Count": list(platform_counts.values())
    })
    
    st.bar_chart(platform_df.set_index("Platform"))

# Tab 4: Logs
with tab4:
    st.subheader("Deployment Logs")
    
    # Allow user to select a deployment
    log_deployments = [(d["id"], f"{d['name']} ({d['platform']})") for d in filtered_deployments]
    
    if log_deployments:
        selected_id = st.selectbox(
            "Select deployment to view logs",
            options=[d[0] for d in log_deployments],
            format_func=lambda x: next((d[1] for d in log_deployments if d[0] == x), "")
        )
        
        # Get selected deployment
        selected_dep = next((d for d in filtered_deployments if d["id"] == selected_id), None)
        
        if selected_dep and "logs" in selected_dep and selected_dep["logs"]:
            st.code(selected_dep["logs"])
        else:
            st.info("No logs available for this deployment.")
    else:
        st.info("No deployments available for the selected filters.")

# Footer
st.markdown("---")
st.markdown("Cloud DevOps Dashboard | Real-time deployment tracking")

# Setup automatic refresh with APScheduler
if config.get("refresh_interval"):
    setup_scheduler(config.get("refresh_interval"))
